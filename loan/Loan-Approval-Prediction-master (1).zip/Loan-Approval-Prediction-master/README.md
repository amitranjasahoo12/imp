# Loan Approval Prediction
[![HitCount](http://hits.dwyl.io/ParthS007/Loan-Approval-Prediction.svg)](http://hits.dwyl.io/ParthS007/Loan-Approval-Prediction)

## Model
- Logistic Regression Model 
    - Accuracy : 80.945%
    - Cross-Validation Score : 80.946%

## Technologies:
- Programming Language: Python
- Libraries: Pandas, Scikit-learn, Matplotlib, Numpy

## Data Source:
- Datahack

Note: Do Check out project report pdf to find out how I used this algorithm.
